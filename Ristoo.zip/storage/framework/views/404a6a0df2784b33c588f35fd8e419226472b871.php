<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <base href="/public">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>admin side</title>
    <?php echo $__env->make('admin.admincss', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style>
        body{
            height: 1500px;
        }

    form {
        position: relative;
        top: 38%;
        left: 18%;
    }

    </style>
</head>
<body>
    <div class="  mx-auto text-center text-bold">
        <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>
    </div>
    <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>



    <div class="container-scroller">
        <?php echo $__env->make('admin.navbaradmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <form action="<?php echo e(url('updatefoodchef',$chef->id)); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label class="form-label">name</label><br>
                            <span style="color: red; font-weight:bold;">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                     <?php echo e($message); ?>

                                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                             </span>
                            <input type="text"  style="color: rgb(246, 5, 5); " value="<?php echo e($chef->name); ?>" name="name" class="form-control"
                                placeholder="entre title" >
                        </div>
                        <div class="mb-3">
                            <label class="form-label">spicialty</label>
                            <br>
                            <span style="color: red; font-weight:bold;">
                                <?php $__errorArgs = ['spicialty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                     <?php echo e($message); ?>

                                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                             </span>
                            <input type="text" name="spicialty" style="color: rgb(255, 91, 3);" value="<?php echo e($chef->specialty); ?>" class="form-control"
                                placeholder="spicialty" >
                        </div>
                        <div class="mb-3">
                            <label class="form-label">choose a new image</label>
                            <input type="file" name="image" style="color: rgb(255, 0, 0);" class="form-control"  >
                        </div>

                        <input type="submit" class="btn btn-primary form-control" value="update"></input>
                    </form>
                    <img src="/chefimage/<?php echo e($chef->image); ?>" width="100" height="100">

                </div>
            </div>
        </div>
    </div>







    <?php echo $__env->make('admin.adminScript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Ristoo\resources\views/admin/updatechef.blade.php ENDPATH**/ ?>