<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>admin side</title>
    <?php echo $__env->make('admin.admincss', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<style>
    body{
        height: 2000px;
    }

    form {
        height: 1000px;
        position: relative;
        top: 32%;
        left: 18%;
    }
    table {
        position: relative;
        top: 38%;
        left: 32%;
    }
</style>

<body>
    <div class="  mx-auto text-center text-bold">
        <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>
    </div>
    <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
    <div class="container-scroller">
        <?php echo $__env->make('admin.navbaradmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <form action="<?php echo e(url('uploadfood')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label class="form-label">title</label>
                            <br>
                        <span style="color: red; font-weight:bold;">
                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                 <?php echo e($message); ?>

                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                         </span>
                            <input type="text" style="color: rgb(252, 9, 9);" name="title" class="form-control"
                                placeholder="entre title" >
                        </div>
                        <div class="mb-3">
                            <label class="form-label">price</label>
                            <br>
                        <span style="color: red; font-weight:bold;">
                            <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                 <?php echo e($message); ?>

                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                         </span>
                            <input type="text" name="price" style="color: rgb(249, 4, 4);" class="form-control"
                                placeholder="entre price" >
                        </div>
                        <div class="mb-3">
                            <br>
                        <span style="color: red; font-weight:bold;">
                            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                 <?php echo e($message); ?>

                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                         </span>
                            <label class="form-label">image</label>
                            <input type="file" name="image" style="color: rgb(251, 5, 5);" class="form-control" >
                        </div>
                        <div class="mb-3">
                            <br>
                            <span style="color: red; font-weight:bold;">
                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                     <?php echo e($message); ?>

                                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                             </span>
                            <label class="form-label">description</label>
                            <input type="text" name="description" style="color: rgb(249, 3, 3);" class="form-control"
                                placeholder="entre description" >
                        </div>
                        <input type="submit" class="btn btn-primary form-control"></input>
                    </form>

                </div>
            </div>
        </div>
    </div>
        <div class="container">
            <div class="row">
                <div class=" col-md-8">
                    <table class="table  table-dark table-hover ">
                        <thead>
                            <tr>
                                <th style="color: green;">FOOD NAME</th>
                                <th style="color: green;">PRICE</th>
                                <th style="color: green;">DESCRIPTION</th>
                                <th style="color: green;">IMAGE</th>
                                <th style="color: green;">ACTION</th>

                            </tr>
                        </thead>
                        <?php $__currentLoopData = $food; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr align="center">
                                <td><?php echo e($food->title); ?></td>
                                <td><?php echo e($food->price); ?></td>
                                <td><?php echo e($food->description); ?></td>
                                <td><img src="/foodimage/<?php echo e($food->image); ?>" ></td>
                                <td align="center">
                                    <a class="btn btn-danger" href="<?php echo e(url('/deletefood',$food->id)); ?>" >delete</a>
                                    <a class="btn btn-primary" href="<?php echo e(url('/updatefood',$food->id)); ?> ">update</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>





    <?php echo $__env->make('admin.adminScript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\Ristoo\resources\views/admin/food.blade.php ENDPATH**/ ?>